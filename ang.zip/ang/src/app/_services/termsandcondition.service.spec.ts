/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { TermsandconditionService } from './termsandcondition.service';

describe('Service: Termsandcondition', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TermsandconditionService]
    });
  });

  it('should ...', inject([TermsandconditionService], (service: TermsandconditionService) => {
    expect(service).toBeTruthy();
  }));
});
