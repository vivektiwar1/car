/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { ExtramodulepriceService } from './extramoduleprice.service';

describe('Service: Extramoduleprice', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ExtramodulepriceService]
    });
  });

  it('should ...', inject([ExtramodulepriceService], (service: ExtramodulepriceService) => {
    expect(service).toBeTruthy();
  }));
});
