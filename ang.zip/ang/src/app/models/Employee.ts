export interface Employee {
    id: string;
    firstName: string;
    lastName: string;
    userName: string;
    email: string;
    address: string;
    phone: string;
    companyName: string;
    Role: string;
}
