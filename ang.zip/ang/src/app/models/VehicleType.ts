
export interface VehicleType {
    id: string;
    name: string;
    companyId: string;
    description: string;
    company: any;

    // form data
    companies: any[];
}
