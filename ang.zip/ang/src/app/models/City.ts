export interface City {
    id: string;
    name: string;
    countryId: string;
}
