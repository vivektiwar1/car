export interface CurrencyFormat {
    id: string;
    format: string;
}
