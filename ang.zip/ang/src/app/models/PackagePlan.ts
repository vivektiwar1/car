export interface PackagePlan {
    id: string;
    name: string;
    description: string;
    isDeleted: boolean;
}
