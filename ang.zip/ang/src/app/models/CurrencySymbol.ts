export interface CurrencySymbol {
    id: string;
    symbol: string;
}
