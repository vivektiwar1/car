export interface ExtraModule {
    id: string;
    name: string;
    description: string;
}
