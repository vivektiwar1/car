export interface VehicleCategory {
    id: string;
    name: string;
    description: string;
    isDeleted: boolean;
}