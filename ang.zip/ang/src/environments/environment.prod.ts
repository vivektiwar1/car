export const environment = {
  production: true,
  apiUrl: 'http://drilonj-001-site1.etempurl.com/api/'
};
